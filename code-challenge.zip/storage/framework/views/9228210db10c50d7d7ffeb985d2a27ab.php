<?php $__env->startSection('backButton'); ?>
<div class="col-1 d-flex flex-column">
    <a href="<?php echo e(route('courses.corridor', ['course_id' => $course->id, 'unit_id' => $unit_id])); ?>" class="btn btn-primary-custom"><i class='bx bx-left-arrow-alt mt-1 fs-4' ></i></i></a>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagename', "Assessment - $course->name"); ?>  
<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(Auth::user()->isInstructor()): ?>
        <div class="row mb-5 justify-content-end">
            <div class="col-3 d-flex">
                <a class="btn btn-outline-primary ms-auto" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class='bx bxs-plus-circle me-2'></i>Add New Assessment</a>
            </div>
        </div>
        <div class="table-responsive">
            <table class="table table-striped-columns">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Title</th>
                        <th scope="col">Description</th>
                        <th scope="col">Due Date</th>
                        <th scope="col">Link</th>
                        
                        <th scope="col">Created At</th>
                        <th scope="col" class="px-5">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $assessments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assessment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($assessment->title); ?></td>
                        <td><?php echo e(Str::limit($assessment->description, 100, '...')); ?></td>
                        <td><?php echo e($assessment->due_date ? $assessment->due_date : '-'); ?></td>
                        <td><a href="<?php echo e($assessment->link); ?>" target="_blank"><?php echo e($assessment->link); ?></a></td>
                        
                        <td><?php echo e($assessment->created_at->format('d M Y')); ?></td>
                        <td>
                            <!-- Edit Button -->
                            <a href="<?php echo e(route('assessment.score', $assessment->id)); ?>" class="btn btn-primary btn-sm">
                                Score
                                
                            </a>
                            <a title="Edit" href="javascript:void(0);" class="btn btn-warning btn-sm edit-user" data-bs-toggle="modal" data-bs-target="#exampleModal" data-id="<?php echo e($assessment->id); ?>" data-title="<?php echo e($assessment->title); ?>" data-description="<?php echo e($assessment->description); ?>" data-due_date="<?php echo e($assessment->due_date); ?>" data-link="<?php echo e($assessment->link); ?>"><i class='bx bxs-edit'></i></a>
                            <form action="<?php echo e(route('assessment.destroy', $assessment->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button title="Delete" type="submit" class="btn btn-danger btn-sm"><i class='bx bxs-trash'></i></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>

        <?php $__currentLoopData = $assessments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assessment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('assessment.show', $assessment->id)); ?>" style="color: inherit; text-decoration: none;width: 100%; height: 100%;">
                <div class="row mt-3">
                    <div class="col">
                        <div class="card mb-3">
                            <div class="row g-0">
                                
                                <div class="col-md-10">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="d-flex align-items-center">
                                                <div class="d-flex">
                                                    <h2 class="fw-bold mb-0">
                                                    <?php echo e($assessment->title); ?>

                                                    </h2>
                                                </div>
                                            </div>
                                            <p class="mb-0 mt-3">
                                                <?php echo e($assessment->description); ?>

                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2 ms-auto">
                                    <div class="card-body">
                                        <div class="row">
                                            <p class="mb-0 text-center">
                                                Score
                                            </p>
                                            <h2 class="fw-bold display-6 text-center">
                                                <?php if($assessment->score == null): ?> -
                                                <?php elseif($assessment->score->score == ""): ?> N/A
                                                <?php else: ?> <?php echo e($assessment->score->score); ?> <?php endif; ?>
                                            </h2>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endif; ?>
    <div class="row mt-3">
        <?php echo e($assessments->links()); ?>

    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Add New Assessment</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="assessmentForm" action="<?php echo e(route('assessment.store', ['course_id' => $course->id, 'unit_id' => $unit_id])); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div id="method"></div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="title" class="form-label">Title<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="title" name="title" required>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea name="description" id="description" class="form-control" rows="3"></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="due_date" class="form-label">Due Date</label>
                        <input type="date" class="form-control" id="due_date" name="due_date">
                    </div>
                    <div class="mb-3">
                        <label for="link" class="form-label">GForm Link<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="link" name="link" required>
                    </div>
                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    // Get modal and form elements
    const modal = document.getElementById('exampleModal');
    const form = document.getElementById('assessmentForm');
    const modalLabel = document.getElementById('exampleModalLabel');
    const methodField = document.getElementById('method');

    // Listen for the show.bs.modal event
    modal.addEventListener('show.bs.modal', function (event) {
        const button = event.relatedTarget; // Button that triggered the modal

        // Extract data attributes from the button
        const id = button.getAttribute('data-id');
        const title = button.getAttribute('data-title');
        const description = button.getAttribute('data-description');
        const due_date = button.getAttribute('data-due_date');
        const link = button.getAttribute('data-link');

        // If id is not null, set the form action to update
        if (id) {
            form.action = "<?php echo e(route('assessment.update', '__id__')); ?>".replace('__id__', id);
            methodField.innerHTML = '<input type="hidden" name="_method" value="PUT">';
            form.querySelector('#title').value = title;
            form.querySelector('#description').value = description;
            form.querySelector('#due_date').value = due_date ? due_date.split('T')[0] : '';
            form.querySelector('#link').value = link;
            modalLabel.textContent = 'Edit Assessment';
        } else {
            // Reset the form for creating a new assessment
            form.action = "<?php echo e(route('assessment.store', ['course_id' => $course->id, 'unit_id' => $unit_id])); ?>";
            methodField.innerHTML = '<input type="hidden" name="_method" value="POST">';
            form.reset();
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ngoding\laravel\code-challenge\resources\views/assessment/index.blade.php ENDPATH**/ ?>