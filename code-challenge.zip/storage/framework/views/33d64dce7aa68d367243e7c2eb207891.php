<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="container">
        <div class="row">
            
            <div class="col-12">
                <h1><?php echo e($subUnits->first()->unit->name); ?></h1>
                <p class="lead"><?php echo e($subUnits->first()->unit->description); ?></p>
            </div>
        </div>
    </div>
    
</div>
<div class="container mt-5">
    <div class="row justify-content-center">
        <?php $__currentLoopData = $subUnits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subUnit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-4">
            <div class="card mb-3" style="max-width: 35rem;">
                <div class="row g-0">
                    <div class="col">
                        <div class="card-body d-flex justify-content-between align-items-center">
                            <?php if($subUnit->video_url != null): ?>
                                <a href="<?php echo e($subUnit->video_url); ?>" class="btn btn-primary-custom"><i class='bx bx-video fs-4'></i></a>
                            <?php else: ?>
                                <a href="<?php echo e(route('quiz', ['subUnitId' => $subUnit->id, 'questionNumber' => 1])); ?>" class="btn btn-primary-custom"><i class='bx bx-edit-alt' ></i></a>
                            <?php endif; ?>
                            <h5 class="card-title"><?php echo e($subUnit->name); ?></h5>
                            <?php if($subUnit->userProgress->count() != 0): ?>
                                
                                    <span class="badge bg-success"><?php echo e($subUnit->userProgress->first()->score); ?></span>
                                
                            <?php elseif($subUnit->video_url == null): ?>
                                <span class="badge bg-warning">Incomplete</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ngoding\laravel\code-challenge\resources\views/courses/subUnit.blade.php ENDPATH**/ ?>