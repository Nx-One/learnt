<?php $__env->startSection('backButton'); ?>
<div class="col-1 d-flex flex-column">
    <a href="<?php echo e(route('courses.corridor', ['course_id' => $course->id, 'unit_id' => $unit_id])); ?>" class="btn btn-primary-custom"><i class='bx bx-left-arrow-alt mt-1 fs-4' ></i></i></a>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagename', "Forum - $course->name"); ?>  
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mb-5 justify-content-end">
        
        <div class="col-2 d-flex">
            <a class="btn btn-outline-primary ms-auto" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class='bx bxs-plus-circle me-2 fs-5'></i>Add New Thread</a>
        </div>
    </div>

    <?php $__currentLoopData = $threads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thread): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('forum.thread.show', $thread->id)); ?>" style="color: inherit; text-decoration: none;width: 100%; height: 100%;">
            <div class="row mt-3">
                <div class="col">
                    <div class="card">
                        <div class="p-3">
                            <div class="d-flex justify-content-between">
                                <div class="d-flex flex-column mb-2">
                                    <div class="d-flex align-items-center">
                                        <div class="d-flex">
                                            <p class="fw-bold mb-0">
                                                <?php echo e($thread->user->name); ?><span class="mx-2">•</span>
                                            </p>
                                            <p class="mb-0 text-primary-custom">
                                                
                                                <?php if($thread->user->roles->first()->name == 'instructor'): ?> Instructor <?php else: ?> Student <?php endif; ?>
                                            </p>
                                        </div>
                                    </div>
                                    <p>
                                        <?php echo e($thread->created_at->format('d F Y')); ?>

                                    </p>
                                </div>

                                <div>
                                    <p class="mr-3 font-weight-500 mb-1">
                                        <i class='bx bx-conversation'></i>
                                        
                                        <?php if($thread->post == null): ?> 0 <?php else: ?> <?php echo e($thread->post->count()); ?> <?php endif; ?> Response(s)
                                    </p>
                                </div>
                            </div>

                            <h5 class="hyphenate text-gray-700 text-md font-weight-600">
                                <?php echo e($thread->title); ?>

                            </h5>

                            <!--Description-->
                            <p class="text-ellipsis-two-row">
                                
                                <?php echo Str::limit(strip_tags($thread->body), 200, '...'); ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="row mt-3">
        <?php echo e($threads->links()); ?>

    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Add New Thread</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('forum.thread.store', ['course_id' => $course->id, 'unit_id' => $unit_id])); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="title" class="form-label">Title</label>
                        <input type="text" class="form-control" id="title" placeholder="Title" name="title" required>
                    </div>
                    <div class="mb-3">
                        <label for="simple" class="form-label">Body</label>
                        <textarea class="form-control" id="simple" rows="3" name="body"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ngoding\laravel\code-challenge\resources\views/forum/index.blade.php ENDPATH**/ ?>