<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="fw-bold">Course</h1>
    <div class="row">
        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6">
                <div class="card p-1 shadow">
                    <img src="<?php echo e(asset('img/course.svg')); ?>" class=" p-2 card-img-top" alt="..." />
                    <div class="card-body">
                        <h3 class="card-title fw-bolder"><?php echo e($course->name); ?></h3>
                        <div class="d-flex justify-content-between align-items-center mt-3">
                            <div class="row">
                                <div class="col-12">
                                    <p class="fw-semibold fs-5 m-0"><?php echo e($course->user->name); ?></p>
                                    <p class="fs-6 m-0"><?php echo e($course->name); ?></p>
                                </div>
                            </div>
                            <a class="btn btn-primary-custom" href="<?php echo e(route('courses.unit', $course->id)); ?>">Open</a>
                        </div>
                        <p class="card-text mt-3"><?php echo e($course->description); ?></p>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <h2 class="mt-5">Articles</h2>
    <div class="row">
        <div id="carouselExample" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                    <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?>">
                        <div class="col">
                            <div class="card mb-3">
                                <div class="row g-0">
                                    <div class="col-md-2">
                                        <img src="<?php echo e(asset('storage/images/' . $article->path_image_title)); ?>" class="rounded-start img-fluid" alt="..." />
                                        
                                    </div>
                                    <div class="col-md-10">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col">
                                                    <p class="card-text"><small class="text-body-secondary"><?php echo e($article->created_at->format('d F Y')); ?></small></p>
                                                    <h5 class="card-title fw-bold m-0"><?php echo e($article->title); ?></h5>
                                                </div>
                                            </div>
                                            <p class="card-text"><?php echo e($article->user->name); ?></p>
                                            <div class="card-text"><?php echo Str::limit($article->content, 100, '...'); ?>

                                                <span>
                                                    <a href="<?php echo e(route('articles.show', $article->id)); ?>" class="link-primary">Read More</a>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

    </div>
</div>

<?php if($showModal): ?>
    <div class="modal fade" id="firstLoginModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="firstLoginModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="fw-bold" id="firstLoginModalLabel">Take a Quick Survey</h5>
                </div>
                <div class="modal-body">
                    <p class="fw-bold">We’d love to hear your thoughts! 🎓</p>
                    <p class="fw-medium">
                        Take a minute to complete a short survey to help us understand your competencies to supports research needs.
                    </p>
                    <iframe src="https://forms.gle/9JzV4Y4ggJ3QWB5Z8" frameborder="0" marginheight="0" marginwidth="0" width="100%" height="590vh"></iframe>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" id="closeModalBtn">Close</button>
                </div>
            </div>
        </div>
    </div>
    
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function () {
        <?php if($showModal): ?>
            var modal = $('#firstLoginModal');
            modal.modal('show');

            $('#closeModalBtn, #modalCloseButton').on('click', function () {
                $.ajax({
                    url: '<?php echo e(route('modal.close')); ?>',
                    type: 'POST',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    success: function (response) {
                        console.log("Modal close state saved.");
                    },
                    error: function () {
                        console.error("Error saving modal close state.");
                    }
                });
            });
        <?php endif; ?>
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ngoding\laravel\code-challenge\resources\views/home.blade.php ENDPATH**/ ?>