<?php $__env->startSection('pagename', 'Courses'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    
    <div class="row">
        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6">
            <div class="card p-1 shadow" >
                <img src="<?php echo e(asset('img/course.svg')); ?>" class="p-2 img-fluid" alt="..." />
                <div class="card-body">
                    <h3 class="card-title fw-bolder"><?php echo e($course->name); ?></h3>
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <div class="row">
                            <div class="col-12">
                                <p class="fw-semibold fs-5 m-0"><?php echo e($course->user->name); ?></p>
                                <p class="fs-6 m-0"><?php echo e($course->name); ?></p>
                            </div>
                        </div>
                        <a class="btn btn-primary-custom" href="<?php echo e(route('courses.unit', $course->id)); ?>">Open</a>
                    </div>
                    <p class="card-text mt-3"><?php echo e($course->description); ?></p>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ngoding\laravel\code-challenge\resources\views/courses/index.blade.php ENDPATH**/ ?>