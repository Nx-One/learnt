<?php $__env->startSection('backButton'); ?>
<div class="col-1 d-flex flex-column">
    <a href="<?php echo e(route('assessment.index', ['course_id' => $course->id, 'unit_id' => $assessment->unit->id])); ?>" class="btn btn-primary-custom"><i class='bx bx-left-arrow-alt mt-1 fs-4' ></i></i></a>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagename', $course->name); ?>  
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($assessment->title); ?></h5>
            <p><?php echo e($assessment->description); ?></p>
            <iframe src="<?php echo e($assessment->link); ?>" frameborder="0" marginheight="0" marginwidth="0" width="100%" height="590vh"></iframe>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ngoding\laravel\code-challenge\resources\views/assessment/show.blade.php ENDPATH**/ ?>