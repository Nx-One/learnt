<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <!-- Favicon -->
        <link rel="icon" type="image/svg+xml" href="<?php echo e(asset('img/favicon.svg')); ?>">

        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net" />
        <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>

        <!-- Styles -->
        <link href="<?php echo e(asset('css/layout.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet" />

        <!-- Tiny MCE -->
        <!-- Place the first <script> tag in your HTML's <head> -->
        <script src="https://cdn.tiny.cloud/1/u3e13p0vei6a50o8h82xd466ed78r8se8v5jra26ephepikj/tinymce/7/tinymce.min.js" referrerpolicy="origin"></script>

        <!-- Place the following <script> and <textarea> tags your HTML's <body> -->
        <script>
        tinymce.init({
            selector: 'textarea#editor',
            plugins: [
            // Core editing features
            'anchor', 'autolink', 'charmap', 'codesample', 'emoticons', 'image', 'link', 'lists', 'media', 'searchreplace', 'table', 'visualblocks', 'wordcount',
            // Your account includes a free trial of TinyMCE premium features
            // Try the most popular premium features until Oct 4, 2024:
            // 'checklist', 'mediaembed', 'casechange', 'export', 'formatpainter', 'pageembed', 'a11ychecker', 'tinymcespellchecker', 'permanentpen', 'powerpaste', 'advtable', 'advcode', 'editimage', 'advtemplate', 'ai', 'mentions', 'tinycomments', 'tableofcontents', 'footnotes', 'mergetags', 'autocorrect', 'typography', 'inlinecss', 'markdown',
            ],
            toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table mergetags | addcomment showcomments | spellcheckdialog a11ycheck typography | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat',
            tinycomments_mode: 'embedded',
            tinycomments_author: 'Author name',
            mergetags_list: [
            { value: 'First.Name', title: 'First Name' },
            { value: 'Email', title: 'Email' },
            ],
            ai_request: (request, respondWith) => respondWith.string(() => Promise.reject('See docs to implement AI Assistant')),
        });
        tinymce.init({
            selector: 'textarea#simple',
            height: 300,
            plugins: [
            // Core editing features
            // 'anchor', 'autolink', 'charmap', 'codesample', 'emoticons', 'image', 'link', 'lists', 'media', 'searchreplace', 'table', 'visualblocks', 'wordcount',
            // Your account includes a free trial of TinyMCE premium features
            // Try the most popular premium features until Oct 4, 2024:
            // 'checklist', 'mediaembed', 'casechange', 'export', 'formatpainter', 'pageembed', 'a11ychecker', 'tinymcespellchecker', 'permanentpen', 'powerpaste', 'advtable', 'advcode', 'editimage', 'advtemplate', 'ai', 'mentions', 'tinycomments', 'tableofcontents', 'footnotes', 'mergetags', 'autocorrect', 'typography', 'inlinecss', 'markdown',
            ],
            toolbar: 'bold italic underline strikethrough | link image media table mergetags | addcomment showcomments',
            tinycomments_mode: 'embedded',
            placeholder: 'Type your message here',
            tinycomments_author: 'Author name',
            mergetags_list: [
            { value: 'First.Name', title: 'First Name' },
            { value: 'Email', title: 'Email' },
            ],
            ai_request: (request, respondWith) => respondWith.string(() => Promise.reject('See docs to implement AI Assistant')),
        });
        </script>
    </head>
    <body id="body-pd" class="bg-secprim">
        <header class="header" id="header">
            <div class="header_toggle"><i class="bx bx-menu" id="header-toggle"></i></div>
            <!-- Right Header -->
            <ul class="navbar-nav ms-auto">
                <li class="nav-item dropdown">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        <?php echo e(Auth::user()->name); ?>

                    </a>

                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        
                        
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();
                                         document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
            </ul>
        </header>
        
        <div class="l-navbar" id="nav-bar">
            <nav class="nav">
                <div>
                    <a href="<?php echo e(route('home')); ?>" class="nav_logo"><img class="nav_logo-icon" src="<?php echo e(asset('img/logo-icon.svg')); ?>" alt="" width="20" height="20" /><span class="nav_logo-name"><?php echo e(config('app.name', 'Laravel')); ?></span> </a>
                    <div class="nav_list">
                        <a href="<?php echo e(route('home')); ?>" class="nav_link <?php echo e((request()->routeIs('home')) || (request()->routeIs('')) ? 'active' : ''); ?>"> <i class="bx bx-grid-alt nav_icon"></i> <span class="nav_name">Dashboard</span> </a>
                        <a href="<?php echo e(route('courses.index')); ?>" class="nav_link <?php echo e((request()->routeIs('courses.*')) ? 'active' : ''); ?>"> <i class='bx bx-book-open nav_icon'></i> <span class="nav_name">Course</span> </a>
                        <a href="<?php echo e(route('articles.index')); ?>" class="nav_link <?php echo e((request()->routeIs('articles.*')) ? 'active' : ''); ?>"><i class='bx bx-notepad nav_icon'></i><span class="nav_name">Article</span> </a>
                        <?php if(Auth::user()->isAdmin()): ?>
                            <a href="<?php echo e(route('users.index')); ?>" class="nav_link <?php echo e((request()->routeIs('users.*')) ? 'active' : ''); ?>"><i class='bx bx-user'></i><span class="nav_name">User</span> </a>
                        <?php endif; ?>
                    </div>
                </div>
                
            </nav>
        </div>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <!--Container Main start-->
        <main class="py-4">
            <div class="row">
                <?php echo $__env->yieldContent('backButton'); ?>
                <div class="col">
                    <h2 class="fw-bold">
                        <?php echo $__env->yieldContent('pagename', 'Dashboard'); ?>
                    </h2>
                </div>
            </div>
            <hr class="mb-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <!--Container Main end-->
        <link href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css" rel="stylesheet" />
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="<?php echo e(asset('js/vendor/jquery-3.6.3.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/script.js')); ?>"></script>
        <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html>
<?php /**PATH D:\Ngoding\laravel\code-challenge\resources\views/layouts/app.blade.php ENDPATH**/ ?>