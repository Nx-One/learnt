<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <?php if(Auth::user()->isInstructor()): ?>
            <div class="col-10">
                <form class="d-flex" role="search">
                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                    
                </form>
            </div>
            <div class="col-2">
                <a href="<?php echo e(route('articles.create')); ?>" class="btn btn-outline-primary"><i class='bx bxs-plus-circle me-2' ></i>Create Article</a>
            </div>
        <?php else: ?>
            <div class="col">
                <form class="d-flex" role="search">
                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                </form>
            </div>
        <?php endif; ?>
    </div>

    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row mt-4">
        <div class="col">
            <div class="card mb-3">
                <div class="row g-0">
                    <div class="col-md-2">
                        <img src="<?php echo e(asset('storage/images/' . $article->path_image_title)); ?>" class="rounded-start img-fluid" alt="..." />
                    </div>
                    <div class="col-md-10">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-10">
                                    <p class="card-text"><small class="text-body-secondary"><?php echo e($article->created_at->format('d F Y')); ?></small></p>
                                    <h5 class="card-title fw-bold m-0"><?php echo e($article->title); ?></h5>
                                </div>
                                <div class="col-md-2 d-flex justify-content-end flex-column mb-3">
                                    <a href="<?php echo e(route('articles.show', $article->id)); ?>" class="btn btn-primary-custom">Open</a>
                                </div>
                            </div>
                            <p class="card-text"><?php echo e($article->user->name); ?></p>
                            <div class="card-text"><?php echo Str::limit($article->content, 100, '...'); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ngoding\laravel\code-challenge\resources\views/articles/index.blade.php ENDPATH**/ ?>