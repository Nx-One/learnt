<?php $__env->startSection('backButton'); ?>
<div class="col-1 d-flex flex-column">
    <a href="<?php echo e(route('courses.corridor', ['course_id' => $course->id, 'unit_id' => $unit_id])); ?>" class="btn btn-primary-custom"><i class='bx bx-left-arrow-alt mt-1 fs-4' ></i></i></a>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagename', "Material - $course->name"); ?>  
<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(Auth::user()->isInstructor()): ?>
        <div class="row mb-5 justify-content-end">
            <div class="col-3 d-flex">
                <a class="btn btn-outline-primary ms-auto" data-bs-toggle="modal" data-bs-target="#exampleModal" data-id="new"><i class='bx bxs-plus-circle me-2'></i>Add New Material</a>
            </div>
        </div>
        <div class="table-responsive">
            <table class="table table-striped-columns">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Title</th>
                        <th scope="col">Description</th>
                        <th scope="col">Type</th>
                        <th scope="col">Link</th>
                        <th scope="col">Image</th>
                        <th scope="col">Created At</th>
                        <th scope="col" class="px-3">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e(Str::limit($material->title, 100, '...')); ?></td>
                        <td><?php echo e(Str::limit($material->description, 100, '...')); ?></td>
                        <td><?php echo e(ucfirst($material->type)); ?></td>
                        <td><a href="<?php echo e($material->link); ?>" target="_blank"><?php echo e($material->link); ?></a></td>
                        <td>
                            <img src="<?php echo e(asset('storage/images/' . $material->image)); ?>" alt="" class="img-fluid">
                        </td>
                        <td><?php echo e($material->created_at->format('d M Y')); ?></td>
                        <td>
                            <!-- Edit Button -->
                            <a title="Edit" href="javascript:void(0);" class="btn btn-warning btn-sm edit-user" data-bs-toggle="modal" data-bs-target="#exampleModal" data-id="<?php echo e($material->id); ?>" data-title="<?php echo e($material->title); ?>" data-description="<?php echo e($material->description); ?>" data-type="<?php echo e($material->type); ?>" data-link="<?php echo e($material->link); ?>"><i class='bx bxs-edit'></i></a>
                            <form action="<?php echo e(route('material.destroy', $material->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button title="Delete" type="submit" class="btn btn-danger btn-sm"><i class='bx bxs-trash'></i></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>

        <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row mt-3 justify-content-center">
                <div class="col-8">
                    <a href="<?php echo e($material->link); ?>" style="color: inherit; text-decoration: none;height: 100%;" target="_blank">
                        <div class="card">
                            <div class="p-3">
                                <div class="row" style="height: 200px;">
                                    <img src="<?php echo e(asset('storage/images/' . $material->image)); ?>" alt="" class="img-fluid" style="height:200px; object-fit: cover" />
                                </div>
                                <div class="row justify-content-between">
                                    
                                    <div class="col d-flex flex-column mb-2">
                                        <div class="d-flex align-items-center mb-1">
                                            <div class="d-flex">
                                                <h2 class="fw-bold mb-0">
                                                <?php echo e($material->title); ?>

                                                </h2>
                                            </div>
                                        </div>
                                        <p class="mb-1 fs-5">
                                            <?php echo e(Str::limit($material->description, 100, '...')); ?>

                                        </p>
                                        <span class="card-text text-body-secondary fs-6 fw-lighter">
                                            <?php echo e(ucfirst($material->type)); ?> •
                                            <?php echo e($material->created_at->format('d M Y')); ?>

                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endif; ?>
    <div class="row mt-3">
        <?php echo e($materials->links()); ?>

    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Add New Material</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="materialForm" action="<?php echo e(route('material.store', ['course_id' => $course->id, 'unit_id' => $unit_id])); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div id="method"></div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="title" class="form-label">Title<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="title" name="title" required>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        
                        <textarea name="description" id="description" class="form-control" rows="3"></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="type" class="form-label">Type</label>
                        <select name="type" id="type" class="form-select">
                            <option value="" disabled selected>Select type</option>
                            <option value="video">Video</option>
                            <option value="document">Document</option>
                            <option value="slides">Slides</option>
                            <option value="photo">Photo</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="link" class="form-label">Link<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="link" name="link" required>
                    </div>
                    <div class="mb-3">
                        <label for="image" class="form-label">Image</label>
                        <input type="file" class="form-control" id="image" name="image">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" id="saveButton">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    // Get modal and form elements
    const modal = document.getElementById('exampleModal');
    const modalLabel = document.getElementById('exampleModalLabel');
    const form = document.getElementById('materialForm');
    const titleInput = document.getElementById('title');
    const descriptionInput = document.getElementById('description');
    const typeInput = document.getElementById('type');
    const linkInput = document.getElementById('link');
    const saveButton = document.getElementById('saveButton');
    const methodField = document.getElementById('method');

    modal.addEventListener('show.bs.modal', function (event) {
        const button = event.relatedTarget; // Button that triggered the modal
        const materialId = button.getAttribute('data-id');
        const title = button.getAttribute('data-title');
        const description = button.getAttribute('data-description');
        const type = button.getAttribute('data-type');
        const link = button.getAttribute('data-link');

        if(materialId === 'new') {
            form.action = "<?php echo e(route('material.store', ['course_id' => $course->id, 'unit_id' => $unit_id])); ?>";
            methodField.innerHTML = '<input type="hidden" name="_method" value="POST">';
            titleInput.value = '';
            descriptionInput.value = '';
            typeInput.value = '';
            modalLabel.textContent = 'Add New Material';
            linkInput.value = '';
        } else {
            // form.action = `/material/update/${materialId}`;
            form.action = "<?php echo e(route('material.update', '__id__')); ?>".replace('__id__', materialId);
            methodField.innerHTML = '<input type="hidden" name="_method" value="PUT">';
            titleInput.value = title;
            descriptionInput.value = description;
            typeInput.value = type;
            linkInput.value = link;
            modalLabel.textContent = 'Edit Material';
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ngoding\laravel\code-challenge\resources\views/material/index.blade.php ENDPATH**/ ?>