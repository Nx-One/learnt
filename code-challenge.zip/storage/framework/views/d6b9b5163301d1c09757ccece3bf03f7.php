<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-10">
                            <h5 class="card-title fw-bold m-0"><?php echo e($article->title); ?></h5>
                        </div>
                        <div class="col-md-2">
                            <p class="card-text"><small class="text-body-secondary"><?php echo e($article->created_at->format('d F Y')); ?></small></p>
                        </div>
                    </div>
                    <p class="card-text"><?php echo e($article->user->name); ?></p>
                </div>
                <div class="mt-3 row justify-content-center">
                    <img style="width: 30rem" src="<?php echo e(asset('storage/images/' . $article->path_image_title)); ?>" class="img-fluid rounded-start" alt="..." />
                </div>
                <div class="card-body">

                    <div class="mt-5 card-text"><?php echo $article->content; ?></div>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ngoding\laravel\code-challenge\resources\views/articles/show.blade.php ENDPATH**/ ?>