<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-3">
            <ul class="list-group">
                <?php for($i = 1; $i <= $totalQuestions; $i++): ?>
                    <li class="list-group-item <?php echo e($i == $questionNumber ? 'active' : ''); ?>">
                        Question <?php echo e($i); ?>

                    </li>
                <?php endfor; ?>
            </ul>
        </div>
        <div class="col-9">
            <h3><?php echo e($question->question); ?></h3>
            <form action="<?php echo e(route('submitAnswer', ['subUnitId' => $question->sub_unit_id, 'questionNumber' => $questionNumber])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                
                <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <input type="radio" name="option_id" value="<?php echo e($option->id); ?>"> <?php echo e($option->option); ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <input type="hidden" name="question_id" value="<?php echo e($question->id); ?>">
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
            <div class="mt-3">
                <?php if($questionNumber > 1): ?>
                    <a href="<?php echo e(route('quiz', ['subUnitId' => $question->sub_unit_id, 'questionNumber' => $questionNumber - 1])); ?>" class="btn btn-secondary">Previous</a>
                <?php endif; ?>
                <?php if($questionNumber < $totalQuestions): ?>
                    <a href="<?php echo e(route('quiz', ['subUnitId' => $question->sub_unit_id, 'questionNumber' => $questionNumber + 1])); ?>" class="btn btn-secondary">Next</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ngoding\laravel\code-challenge\resources\views/courses/quiz.blade.php ENDPATH**/ ?>