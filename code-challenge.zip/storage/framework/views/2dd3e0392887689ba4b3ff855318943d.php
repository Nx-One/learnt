<?php $__env->startSection('pagename', $units->first()->course->name); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="container">
        <div class="row">
            
            <div class="col-12">
                <p class="lead"><?php echo e($units->first()->course->description); ?></p>
            </div>
        </div>
    </div>
    
</div>
<div class="container mt-5">
    <div class="row justify-content-center">
        <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-4">
            <div class="card mb-3" style="max-width: 35rem;">
                <div class="row g-0">
                    <div class="col">
                        <div class="card-body d-flex justify-content-between align-items-center">
                            <h5 class="card-title"><?php echo e($unit->name); ?></h5>
                            <a href="<?php echo e(route('courses.subUnit', ['course_id' => $unit->course->id, 'unit_id' => $unit->id])); ?>" class="btn"><i class='bx bxs-right-arrow-circle fs-3 text-primary' ></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ngoding\laravel\code-challenge\resources\views/courses/unit.blade.php ENDPATH**/ ?>